package cn.dreamtobe.kpswitch.demo.activity;

import android.app.Activity;
import android.os.Bundle;

import cn.dreamtobe.kpswitch.demo.R;


/**
 * Created by Jacksgong on 9/11/15.
 */
public class TranslucentActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_translucent);
    }

}
